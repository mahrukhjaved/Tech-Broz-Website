package Testcases;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
//import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;



public class HomePageTest {
	public String baseUrl = "https://www.techbroz.co.nz/";
	public WebDriver driver;
	
	// This method is to navigate TechBroz URL

	@BeforeMethod

	public void setBaseUrl()
	{

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		driver = new FirefoxDriver();
		driver.get(baseUrl);
	}

	@Test
	public void verifyHomePageTitleTest(){
		String actualTitle = driver.getTitle();
		String expectedTitle = "Discover Computers, Printers, Laptops, Storages And More...";
		Assert.assertEquals("Condition true", actualTitle, expectedTitle);
	}

	@Test
	public void findAllHomePageLinks() 
	{				

		String underConsTitle = "Discover Computers, Printers, Laptops, Storages And More...";					

		List<WebElement> linkElements = driver.findElements(By.tagName("a"));
		//List<WebElement> linkElements = driver.findElements(By.tagName("a"));						
		String[] linkTexts = new String[linkElements.size()];							
		int	i = 0;					

		//extract the link texts of each link element		
		for (WebElement e : linkElements) {							
			linkTexts[i] = e.getText();							
			i++;			
		}		

		//test each link		
		for (String t : linkTexts) {							
			driver.findElement(By.linkText(t)).click();					
			if (driver.getTitle().equals(underConsTitle)) {							
				System.out.println("\"" + t + "\""								
						+ " is under construction.");			
			} else {			
				System.out.println("\"" + t + "\""								
						+ " is working.");			
			}		
			driver.navigate().back();			
		}		
		driver.quit();			
	}
	
	//Verifying redirection to the terms and conditions page
    @Test
    public void termsRedirectionTest()
    {
        WebElement termsLink = driver.findElement(By.linkText("TERMS & CONDITIONS"));
        termsLink.click();      

        Set <String> allWindows = driver.getWindowHandles();

        for(String handle : allWindows)
        {
            driver.switchTo().window(handle);
        }                   

        String expectedURL = "https://www.techbroz.co.nz/terms-and-conditions/";
        String actualURL = driver.getCurrentUrl();
        //System.out.println(actualURL);
        Assert.assertEquals(actualURL, expectedURL);

        String expectedTitle = "Terms & Conditions | Techbroz";
        String actualTitle = driver.getTitle();
        //System.out.println(actualTitle);
        Assert.assertEquals(actualTitle, expectedTitle);        
    }
	
	

	@AfterTest
	public void tearDown()
	{
		
		driver.quit();
		driver.close();
	}


}
