package Testcases;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class My_AccountTest {
	public WebDriver driver;
	public String username = "mahrukh";  //your username
	public String password = "1234ABCD";      //your access key

	boolean status = false;


	//Setting up capabilities to run our test script
	@Parameters(value= {"browser","version"})
	@BeforeClass
	public void setUp(String browser, String version) throws Exception {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("browserName", browser);
		capabilities.setCapability("version", version);
		capabilities.setCapability("platform", "win10"); // If this cap isn't specified, it will just get the any available one
		capabilities.setCapability("build", "TechBroz");
		capabilities.setCapability("name", "My_AccountTest");
		capabilities.setCapability("network", true); // To enable network logs
		capabilities.setCapability("visual", true); // To enable step by step screenshot
		capabilities.setCapability("video", true); // To enable video recording
		capabilities.setCapability("console", true); // To capture console logs
		try {
			driver = new RemoteWebDriver (new URL("https://" + username + ":" + password), capabilities);
		} catch (MalformedURLException e) {
			System.out.println("Invalid grid URL");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	//Opening browser with the given URL and navigate to Registration Page
	@BeforeMethod
	public void openBrowser()
	{
		driver.manage().deleteAllCookies();

		driver.get("https://www.techbroz.co.nz/");

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);

		WebElement signUpButton = driver.findElement(By.linkText("Register"));
		signUpButton.click(); 

	}

	//Verifying elements on Registration page
	@Test
	public void verifyElemntsOnMyAccountTest()
	{
		WebElement MyAccountLogo = driver.findElement(By.xpath("//header/div[1]/div[1]/div[1]/div[1]/a[1]/img[1]"));
		MyAccountLogo.isDisplayed();

		WebElement RegisterTitle = driver.findElement(By.xpath("//h2[contains(text(),'Register')]"));
		RegisterTitle.isDisplayed();

		WebElement LogInTitle = driver.findElement(By.xpath("//h2[contains(text(),'Login')]"));
		LogInTitle.isDisplayed();

		WebElement PrivacyPolicyText = driver.findElement(By.linkText("privacy policy"));
		PrivacyPolicyText.isDisplayed();

		WebElement loginLinkText = driver.findElement(By.xpath("//button[contains(text(),'Log in')]"));
		loginLinkText.isDisplayed();

		WebElement usernameTextbox = driver.findElement(By.cssSelector("#username"));
		usernameTextbox.isDisplayed();

		WebElement passwordTextbox = driver.findElement(By.cssSelector("#password"));
		passwordTextbox.isDisplayed();

		WebElement rememberMeCheckbox = driver.findElement(By.cssSelector("#rememberme"));
		rememberMeCheckbox.isDisplayed();

		WebElement registerLinkText = driver.findElement(By.xpath("//button[contains(text(),'Register')]"));
		registerLinkText.isDisplayed();

		WebElement firstNameTextbox = driver.findElement(By.cssSelector("#reg_billing_first_name"));
		firstNameTextbox.isDisplayed();

		WebElement lastNameTextbox = driver.findElement(By.cssSelector("#reg_billing_last_name"));
		lastNameTextbox.isDisplayed();

		WebElement phoneTextbox = driver.findElement(By.cssSelector("#reg_billing_phone"));
		phoneTextbox.isDisplayed();

		WebElement emailTextbox = driver.findElement(By.cssSelector("#reg_email"));
		emailTextbox.isDisplayed();

		WebElement password_Textbox = driver.findElement(By.cssSelector("#reg_password"));
		password_Textbox.isDisplayed();

	}

	//To verify the redirections with the links present on the pages.

	//Verifying redirection to the terms and conditions page
	@Test
	public void termsRedirectionTest()
	{
		WebElement termsLink = driver.findElement(By.linkText("TERMS & CONDITIONS"));
		termsLink.click();      

		Set <String> allWindows = driver.getWindowHandles();

		for(String handle : allWindows)
		{
			driver.switchTo().window(handle);
		}                   

		String expectedURL = "https://www.techbroz.co.nz/terms-and-conditions/";
		String actualURL = driver.getCurrentUrl();
		//System.out.println(actualURL);
		Assert.assertEquals(actualURL, expectedURL);

		String expectedTitle = "Terms & Conditions | Techbroz";
		String actualTitle = driver.getTitle();
		//System.out.println(actualTitle);
		Assert.assertEquals(actualTitle, expectedTitle);        
	}

	//Verifying redirection to the privacy policy page
	@Test
	public void privacypolicyRedirectionTest()
	{
		WebElement privacyPolicyLink = driver.findElement(By.linkText("privacy policy"));
		privacyPolicyLink.click();      

		Set <String> allWindows = driver.getWindowHandles();

		for(String handle : allWindows)
		{
			driver.switchTo().window(handle);
		}                   

		String expectedURL = "https://www.techbroz.co.nz/privacy-policy/";
		String actualURL = driver.getCurrentUrl();
		//System.out.println(actualURL);
		Assert.assertEquals(actualURL, expectedURL);

		String expectedTitle = "PRIVACY STATEMENT | Techbroz";
		String actualTitle = driver.getTitle();
		//System.out.println(actualTitle);
		Assert.assertEquals(actualTitle, expectedTitle);        
	}

	//Verifying redirection to the Registration page from Home Page
	@Test
	public void RegistrationRedirectionTest()
	{
		WebElement registerationLink = driver.findElement(By.linkText("Register"));
		registerationLink.click();

		String expectedURL = "https://www.techbroz.co.nz/my-account-2/";
		String actualURL = driver.getCurrentUrl();
		//System.out.println(actualURL);
		Assert.assertEquals(actualURL, expectedURL);

		String expectedTitle = "My Account | Techbroz";
		String actualTitle = driver.getTitle();
		//System.out.println(actualTitle);
		Assert.assertEquals(actualTitle, expectedTitle);        
	}

	//Verifying redirection to the Login Page from Home Page
	@Test
	public void loginRedirectionTest()
	{
		WebElement LoginLink = driver.findElement(By.linkText("Sign in"));
		LoginLink.click();

		String expectedURL = "https://www.techbroz.co.nz/my-account-2/";
		String actualURL = driver.getCurrentUrl();
		//System.out.println(actualURL);
		Assert.assertEquals(actualURL, expectedURL);

		String expectedTitle = "My Account | Techbroz";
		String actualTitle = driver.getTitle();
		//System.out.println(actualTitle);
		Assert.assertEquals(actualTitle, expectedTitle);        
	}

	//Verifying redirection to the promotions Page from Login Page
	@Test
	public void promotionsRedirectionTest()
	{
		WebElement promotionsLink = driver.findElement(By.linkText("Promotions"));
		promotionsLink.click();

		String expectedURL = "https://www.techbroz.co.nz/promotions/";
		String actualURL = driver.getCurrentUrl();
		//System.out.println(actualURL);
		Assert.assertEquals(actualURL, expectedURL);

		String expectedTitle = "Page Not Found | Techbroz";
		String actualTitle = driver.getTitle();
		//System.out.println(actualTitle);
		Assert.assertEquals(actualTitle, expectedTitle);        
	}

	//Verifying redirection to the product category Page from Login Page
	@Test
	public void productCategoryRedirectionTest()
	{
		WebElement productCategoryLink = driver.findElement(By.linkText("Search by product category"));
		WebElement pcPeripheralsLink = driver.findElement(By.xpath("//header/div[1]/div[2]/div[1]/ul[1]/li[1]/ul[1]/li[1]/a[1]"));
		WebElement computerCaseLink= driver.findElement(By.xpath("//header/div[1]/div[2]/div[1]/ul[1]/li[1]/ul[1]/li[1]/ul[1]/li[1]/a[1]"));
		// productCategoryLink.click();

		Actions action = new Actions(driver);
		action.moveToElement(productCategoryLink).perform();
		action.moveToElement(pcPeripheralsLink).perform();
		action.moveToElement(computerCaseLink).click().perform();

		String expectedURL = "https://www.techbroz.co.nz/product-category/computer-accessories/computer-case-and-accessory-gaming/";
		String actualURL = driver.getCurrentUrl();
		//System.out.println(actualURL);
		Assert.assertEquals(actualURL, expectedURL);

		String expectedTitle = "Computer Case and Accessory – Gaming | Techbroz";
		String actualTitle = driver.getTitle();
		//System.out.println(actualTitle);
		Assert.assertEquals(actualTitle, expectedTitle);        
	}


	//Verifying redirection to the landing page
	@Test
	public void landingPageRedirectionTest()
	{
		WebElement TechBrozLogo = driver.findElement(By.xpath("//header/div[2]/div[1]/div[2]/a[1]/img[1]"));
		TechBrozLogo.click();

		String expectedURL = "https://www.techbroz.co.nz/";
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(actualURL, expectedURL);

		String expectedTitle = "";
	}

	// Closing the browser session after completing each test case
	@AfterMethod
	public void tearDown() throws Exception {
		if (driver != null) {
			((JavascriptExecutor) driver).executeScript("Login-status=" + status);
			driver.quit();
		}

	} 
}
