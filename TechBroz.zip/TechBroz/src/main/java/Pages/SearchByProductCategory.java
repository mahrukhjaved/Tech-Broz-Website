package Pages;

public class SearchByProductCategory {

}
