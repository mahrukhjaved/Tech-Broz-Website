package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class HomePage {
	WebDriver driver;

	By logo = By.xpath("/html[1]/body[1]/div[3]/div[1]/header[1]/div[2]/div[1]/div[2]/a[1]/img[1]");
	By titleText = By.xpath("/html[1]/head[1]/title[1]");
	By searchBar = By.id("dgwt-wcas-search-input-10b6");
	By HomePageTitle = By.xpath("/html[1]/body[1]");
	By banner = By.xpath("/html[1]/body[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/main[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[2]/div[1]");
	By comparePage = By.className("ec ec-compare");
	By wishListPage = By.className("ec ec-favorites");
	By myAccountPage = By.linkText("My Account");
	By viewCartPage = By.xpath("//a[contains(@class,'footer-cart-contents')]//i[contains(@class,'ec ec-shopping-bag')]");
	By productCategoryPage = By.linkText("Search by product category");
	By pcPeripheralsandAccessories = By.xpath("/html[1]/body[1]/div[3]/div[1]/header[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/ul[1]/li[1]/a[1]");
	By connectivityDevices = By.linkText("Connectivity Devices");
	By computerAndTablets = By.xpath("/html[1]/body[1]/div[3]/div[1]/header[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/ul[1]/li[3]/a[1]");
	By promotionsPage = By.linkText("Promotions");
	By monitorsPage = By.xpath("//a[@class='dropdown-toggle'][contains(text(),'Monitors')]");
	By laptopsandTabletsPage = By.linkText("Laptops & Tablets");
	By contactUsPage = By.linkText("Contact");
	By aboutUsPage = By.linkText("About Us");
	By siteMapPage = By.linkText("Sitemap");
	By trackYourOrderPage = By.linkText("Track your Order");
	By privacyStatementPage = By.linkText("PRIVACY STATEMENT");
	By termsAndConditionsPage = By.linkText("TERMS & CONDITIONS");

	public HomePage(WebDriver driver) {
		this.driver=driver;
	}

	public String verifyHomePageTitle(){
		return driver.getTitle();

	}

	public HomePage clickLogo() {
		driver.findElement(By.xpath("//div[@class='header-site-branding']//img[@class='img-header-logo']")).click();
		return new HomePage(driver);
	}

	public void searchBarTextBox() {
		driver.findElement(By.id("dgwt-wcas-search-input-10b6")).sendKeys(Keys.ENTER);

	}

	public Compare clickOnCompareLink() {
		driver.findElement(By.className("ec ec-compare")).click();
		return new Compare();
	}

	public Wishlist clickOnwishlistLink() {
		driver.findElement(By.className("ec ec-favorites")).click();
		return new Wishlist();

	}

	public My_Account clickOnMyAccountLink() {
		driver.findElement(By.xpath("/html[1]/body[1]/div[3]/div[1]/header[1]/div[1]/div[1]/div[3]/div[3]/a[1]/i[1]")).click();
		return new My_Account(driver);
	}
	public Shopping_Cart clickOnviewCartLink() {
		driver.findElement(By.xpath("/html[1]/body[1]/div[3]/div[1]/header[1]/div[1]/div[1]/div[3]/div[4]/a[1]/i[1]")).click();
		return new Shopping_Cart();
	}

	public SearchByProductCategory clickOnProductCategoryLink() {
		driver.findElement(By.linkText("Search by product category")).click();
		return new SearchByProductCategory();

	}

	public Promotions clickOnPromotionsLink() {
		driver.findElement(By.linkText("Promotions")).click();
		return new Promotions();
	}

	public Monitors clickOnMonitorsLink() {
		driver.findElement(By.xpath("//a[@class='dropdown-toggle'][contains(text(),'Monitors')]")).click();
		return new Monitors();
	}

	public Laptops_And_Tablets clickOnLaptopsAndTabletsLink() {
		driver.findElement(By.linkText("Laptops & Tablets")).click();
		return new Laptops_And_Tablets();
	}


	public Contact clickOnContactsLink() {
		driver.findElement(By.linkText("Contact")).click();
		return new Contact();

	}

	public About_Us clickOnAboutUsLink() {
		driver.findElement(By.linkText("About Us")).click();
		return new About_Us();

	}

	public Sitemap clickOnSiteMapLink() {
		driver.findElement(By.linkText("Sitemap")).click();
		return new Sitemap();

	}

	public Track_Your_Order clickOnTrackYourOrderLink() {
		driver.findElement(By.linkText("Track your Order")).click();
		return new Track_Your_Order();

	}
	public Privacy_Statement clickOnPrivacyStatementLink() {
		driver.findElement(By.linkText("PRIVACY STATEMENT")).click();
		return new Privacy_Statement();

	}
	public Terms_And_Conditions clickOnTermsAndConditionsLink() {
		driver.findElement(By.linkText("TERMS & CONDITIONS")).click();
		return new Terms_And_Conditions();

	}

}

