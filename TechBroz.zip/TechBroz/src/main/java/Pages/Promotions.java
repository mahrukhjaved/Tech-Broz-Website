package Pages;

public class Promotions {

}
