package Pages;

public class Wishlist {

}
