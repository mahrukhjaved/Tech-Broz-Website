package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class My_Account {

	WebDriver driver;

	By logo = By.xpath("//header/div[2]/div[1]/div[2]/a[1]/img[1]");
	By searchBar = By.cssSelector("#dgwt-wcas-search-input-1bdb");
	By MyAccountPageTitle = By.xpath("//head/meta[7]");
	By comparePage = By.xpath("//header/div[1]/div[1]/div[3]/div[1]/a[1]/i[1]");
	By wishListPage = By.xpath("//header/div[1]/div[1]/div[3]/div[2]/a[1]/i[1]");
	By myAccountPage = By.xpath("//header/div[2]/div[1]/div[3]/ul[1]/li[2]/a[1]/i[1]");
	By viewCartPage = By.xpath("//header/div[2]/div[1]/div[3]/ul[1]/li[3]/a[1]/i[1]");
	By productCategoryPage = By.linkText("Search by product category");
	By promotionsPage = By.linkText("Promotions");
	By monitorsPage = By.xpath("//header/div[1]/div[2]/div[1]/ul[1]/li[3]/a[1]");
	By laptopsandTabletsPage = By.linkText("Laptops & Tablets");
	By contactUsPage = By.linkText("Contact");
	By aboutUsPage = By.linkText("About Us");
	By siteMapPage = By.linkText("Sitemap");
	By trackYourOrderPage = By.linkText("Track your Order");
	By privacyStatementPage = By.linkText("PRIVACY STATEMENT");
	By termsAndConditionsPage = By.linkText("TERMS & CONDITIONS");
	By userName = By.cssSelector("#username");
	By password = By.cssSelector("#password");
	By rememberMecheckbox = By.cssSelector("#rememberme");
	By LogInButton = By.xpath("//button[contains(text(),'Log in')]");
	By forgotPassword = By.linkText("Lost your password?");
	By firstName = By.cssSelector("#reg_billing_first_name");
	By lastName = By.cssSelector("#reg_billing_last_name");
	By phoneNumber = By.cssSelector("#reg_billing_phone");
	By emailAddress = By.cssSelector("#reg_email");
	By registerButton = By.xpath("//button[contains(text(),'Register')]");


	public My_Account(WebDriver driver) {
		this.driver=driver;
	}

	public String verifyMyAccountPageTitle(){
		return driver.getTitle();
	}

	public My_Account clickLogo() {
		driver.findElement(By.xpath("//header/div[1]/div[1]/div[1]/div[1]/a[1]/img[1]")).click();
		return new My_Account(driver);
	}
	public void searchBarTextBox() {
		driver.findElement(By.cssSelector("#dgwt-wcas-search-input-1bdb")).sendKeys(Keys.ENTER);

	}

	public Compare clickOnCompareLink() {
		driver.findElement(By.xpath("//header/div[1]/div[1]/div[3]/div[1]/a[1]/i[1]")).click();
		return new Compare();
	}

	public Wishlist clickOnwishlistLink() {
		driver.findElement(By.xpath("//header/div[1]/div[1]/div[3]/div[2]/a[1]/i[1]")).click();
		return new Wishlist();

	}

	public My_Account clickOnMyAccountLink() {
		driver.findElement(By.xpath("///header/div[2]/div[1]/div[3]/ul[1]/li[2]/a[1]/i[1]")).click();
		return new My_Account(driver);
	}
	public Shopping_Cart clickOnviewCartLink() {
		driver.findElement(By.xpath("//header/div[2]/div[1]/div[3]/ul[1]/li[2]/a[1]/i[1]")).click();
		return new Shopping_Cart();
	}

	public void setUserName(String strUsername) {

		driver.findElement(userName).sendKeys(strUsername);
	}
	
	public void setPassword(String strPassword) {

		driver.findElement(password).sendKeys(strPassword);
	}
	
	public void rememberMe() {

		driver.findElement( By.cssSelector("#rememberme")).click();

	}

	public void clickLogIn() {

		driver.findElement(By.xpath("//button[contains(text(),'Log in')]")).click();

	}
	public void clickForgotPassword() {

		driver.findElement(By.linkText("Lost your password?")).click();

	}
	public void setFirstName(String strFirstName) {

		driver.findElement(firstName).sendKeys(strFirstName);
	}
	public void setLastName(String strLastName) {

		driver.findElement(lastName).sendKeys(strLastName);
	}
	
	public void setphoneNumber(String strphoneNumber) {

		driver.findElement(phoneNumber).sendKeys(strphoneNumber);
	}
	public void setemailAddress(String strEmail) {

		driver.findElement(emailAddress).sendKeys(strEmail);
	}
	
	public Privacy_Statement clickOnPrivacyStatementLink() 
	{
		driver.findElement(By.linkText("PRIVACY STATEMENT")).click();
		return new Privacy_Statement();
	}
	
	public Terms_And_Conditions clickOnTermsAndConditionsLink() {
		driver.findElement(By.linkText("TERMS & CONDITIONS")).click();
		return new Terms_And_Conditions();

	}

	public void clickRegisterButton() 
	{

		driver.findElement(By.xpath("//button[contains(text(),'Register')]")).click();

	}
}
